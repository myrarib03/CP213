package cp213;

import java.time.LocalDate;

/**
 * Tests the Student class.
 *
 * @author Myra Ribeiro, 169030590
 * @version 2022-01-17
 */
public class Main {

    public static void main(String[] args) {
	final String line = "-".repeat(40);
	int id = 123456;
	String surname = "Brown";
	String forename = "David";
	LocalDate birthDate = LocalDate.parse("1962-10-25");
	Student student = new Student(id, surname, forename, birthDate);
	System.out.println("New Student:");
	System.out.println(student);
	System.out.println(line);
	System.out.println("Test Getters");

	// call getters here

	System.out.println(line);
	System.out.println("Test Setters");

	// call setters here

	System.out.println("Updated Student:");
	System.out.println(student);
	System.out.println(line);
	System.out.println("Test compareTo");

	// create new Students - call comparisons here
	Student studentTwo = new Student(134567, "Hilly", "Riggs", birthDate);
	Student studentThree = new Student(145789, "Angela", "Daphne", birthDate);
	System.out.println("Student 2:");
	System.out.println(studentTwo);
	System.out.println("");
	System.out.println("Student 3:");
	System.out.println(studentThree);
	System.out.println("");
	System.out.println("Comparison:");
	System.out.println(studentTwo.compareTo(studentThree));
    }

}
