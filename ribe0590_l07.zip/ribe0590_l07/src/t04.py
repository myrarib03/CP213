"""
-------------------------------------------------------
[Task 4, Lab 7]
-------------------------------------------------------
Author:  Myra Ribeiro
ID:      169030590
Email:   ribe0590@mylaurier.ca
__updated__ = "2024-06-22"
-------------------------------------------------------
"""
# Imports
from List_linked import List
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


source = List()
source.append(22)
source.append(33)
source.append(11)
source.append(55)
source2 = List()
source2.append(11)
source2.append(55)
source2.append(44)

source3 = List()


print(source3.intersection_r(source, source2))

for i in source3:
    print(i)
