"""
-------------------------------------------------------
[Assignment 6, Task 3]
-------------------------------------------------------
Author:  Myra Ribeiro
ID:      169030590
Email:   ribe0590@mylaurier.ca
__updated__ = "2024-06-23"
-------------------------------------------------------
"""
# Imports
from Deque_linked import Deque
from Deque_linked import _Deque_Node
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


target = Deque()
target.insert_front(1)
target.insert_front(2)
source = Deque()
source.insert_front(1)
source.insert_front(2)
source2 = Deque()
source2.insert_front(3)

for i in target:
    print(i)

new_queue = Deque()

new_queue.insert_front(1)
for i in target:
    print(i)

print(source == target)

for i in target:
    print(i)

print(source.is_empty())

print(target.peek_rear())
print(target.peek_front())
