"""
-------------------------------------------------------
[Assignment 6, Task 2]
-------------------------------------------------------
Author:  Myra Ribeiro
ID:      169030590
Email:   ribe0590@mylaurier.ca
__updated__ = "2024-06-23"
-------------------------------------------------------
"""
# Imports
from Priority_Queue_linked import Priority_Queue
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


target = Priority_Queue()
target.insert(1)
target.insert(2)
source = Priority_Queue()
source.insert(1)
source.insert(2)
source2 = Priority_Queue()
source2.insert(3)

for i in target:
    print(i)

target.remove()

target.combine(source, source2)

new_queue = Priority_Queue()

new_queue.insert(1)
for i in target:
    print(i)

print(source == target)

target._append_queue(new_queue)

for i in target:
    print(i)

print(source.is_empty())

target1, target2 = target.split_alt()

target1._move_front_to_rear(target2)

print(target1.peek())
